﻿class HojaPatronesRosembergEscobar
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese un número entero no más de 6 cifras: ");
        int numIng = int.Parse(Console.ReadLine());

        if(numIng > 0 && numIng <= 999999)
        {
            if (numIng <= 3) {
                Console.WriteLine($"El número {numIng} es primo.");
            }
            else if (numIng % 2 == 0 || numIng % 3 == 0) {
                Console.WriteLine($"El número {numIng} no es primo.");
            }
            else {
                for(int res = 2; res * res <=numIng; res++){
                    if (numIng % res == 0){
                        Console.WriteLine($"El número {numIng} no es primo.");
                        return;
                    }
                }
                Console.WriteLine($"El número {numIng} es primo.");
            }

        }
        else 
        {
            Console.WriteLine("Número inválido, ingrese otro.");
        }
    }
}